<?php
/**
 * Plugin Name: LUMN - Prospecta Plugin
 * Plugin URI: https://wiki.dentalcmo.com/dcmo-prospecta
 * Description: This plugin is used to help implement ProspectaMarketing requirements documents.
 * Version: 2025.02.19
 * Author: DentalCMO - Alex Taylor
 * Author URI: https://getlumn.com
 */

// Includes code related to the admin dashboard page
include_once plugin_dir_path(__FILE__) . 'menu-page.php';

// Includes code related to the ctt form
include_once plugin_dir_path(__FILE__) . 'ctt-form.php';

// Includes code related to any styles or scripts
include_once plugin_dir_path(__FILE__) . 'style-script.php';

// Includes miscellaneous code if the above is not appropriate
include_once plugin_dir_path(__FILE__) . 'functions.php';

// Enable update checker
require plugin_dir_path(__FILE__) . 'plugin-update-checker/plugin-update-checker.php';
use YahnisElsts\PluginUpdateChecker\v5\PucFactory;

$myUpdateChecker = PucFactory::buildUpdateChecker(
	'https://getlumn.com/dcmo-prospecta/version.json',
	__FILE__, //Full path to the main plugin file or functions.php.
	'dcmo-prospecta'
);
