<?php
/**
 * DCMO Prospecta Plugin CTT Form
 *
 * @package dcmo-prospecta
 */

/**
 * DCMO Prospecta Plugin CTT Form
 *
 * @author DentalCMO - Landon Hatch
 */

/**
 * Render the Prospecta CTT Form
 *
 * Puts together the CTT Form from the passed details and outputs it when called.
 *
 * @author DentalCMO - Alex Taylor
 * @param string/array - string signifies a single account number
 * 		array signifies multiple accounts.  The array needs to be in this format:
 * 		array(
 * 			array("Label","AccountID"),
 * 			array("Label","AccountID")
 * 		)
 * @global $pm_ctt_rendered - used to prevent multiple renders of the form
 */

 $options = get_option('dcmo_pm_options','');
 if (isset($options['acc_id']) && !empty($options['acc_id'])) {
     $is_multi = ($options['is_multi'] === '1') ? true : false;

     if (!$is_multi) {
         $args = $options['acc_id'];
     } else {
         $args = $options['multi_details'];
     }

     add_action('wp_footer', function() use ($args, $options) {
		render_ctt_form($args, $options['practice_name'] ?? 'Your Practice Name');
	});
 }

 $practice_name = $options['practice_name'] ?? 'Your Practice Name';

 function render_ctt_form($details, $practice_name = 'Your Practice Name') {
	global $pm_ctt_rendered;

	if (!$pm_ctt_rendered) {
		$is_multi = (is_array($details)) ? true : false;

        $ctt_form = '';

		$ctt_form .= '<div id="clickToCallOverlay" class="prospecta-ctt hide">';
		if ($is_multi) {
			$ctt_form .= '<div id="clickToCallForm" class="multi ctt-flex vertAlign">';
		}
		else {
			$ctt_form .= '<div id="clickToCallForm" class="ctt-flex vertAlign">';
		}

		$ctt_form .= '<div class="formSection"><h4>TEXT OUR OFFICE</h4>';
		$ctt_form .= '<form action="https://ivlrest.voiceelements.com/clicksms" method="get" id="form1">';

		$ctt_form .= '<label id="lblName">Your Name: </label>';

		$ctt_form .= '<input name="ClickName" type="text" id="ClickName" onkeyup="autotab(this, &#39;PhoneNumber1&#39;);" required />';

		$ctt_form .= '<label id="lblPhoneNumber">Your Cell Phone Number: </label>';

		$ctt_form .= '<input name="PhoneNumber1" type="text" id="PhoneNumber1" maxlength="3" placeholder="(&nbsp;&nbsp;&nbsp;)" size="2" onkeypress="return isNumberKey(this, event)" onkeyup="autotab(this, &#39;PhoneNumber2&#39;);" required />';
		$ctt_form .= '<input name="PhoneNumber2" type="text" id="PhoneNumber2" maxlength="3" size="2" onkeypress="return isNumberKey(this, event)" onkeyup="autotab(this, &#39;PhoneNumber3&#39;);" required />';
		$ctt_form .= '<input name="PhoneNumber3" type="text" id="PhoneNumber3" maxlength="4" size="3" onkeypress="return isNumberKey(this, event)" onkeyup="autotab(this, &#39;text&#39;);" required />';

		if($is_multi) {
			$ctt_form .= '<select name="account" id="account">';
			$ctt_form .= '<option selected="true" disabled="disabled">Select an Office</option>';

			foreach($details as $key => $multi_details) {
				$ctt_form .= '<option value="' . $multi_details[1] . '">' . $multi_details[0] . '</option>';
			}
			$ctt_form .= '</select>';
		}

		$ctt_form .= '<input type="hidden" name="from" id="ctcPhone" value="" />';
		$ctt_form .= '<input type="hidden" name="originatingurl" id="originatingurl" value="" />';
		$ctt_form .= '<input type="hidden" name="referringurl" id="referringurl" value="" />';

		if(!$is_multi) {
			$ctt_form .= '<input type="hidden" name="account" id="account" value=' . $details . ' />';
		}

		$ctt_form .= '<label for="text">Text Message:</label><textarea name="text" id="text" rows="5" cols="30" maxlength="1000" required></textarea><p>Text message is limited to 1000 characters.</p>';
		$ctt_form .= '<input type="checkbox" id="sms-checkbox" required name="CTTconsent"> <span id="sms-consent">I consent to allow ' . esc_html($practice_name) . ' to send text messages to my wireless phone number. Message frequency may vary. I understand I may opt-out at any time by replying "Stop".</span><br/>';
		$ctt_form .= '<input type="submit" name="btnSubmit" value="Send Text" id="btnSubmit" />';

		$ctt_form .= '</form></div>';

		$ctt_form .= '<div class="howItWorksSection"><h4>HOW IT WORKS</h4>';
		$ctt_form .= '<ol><li>Enter your Name.</li><li>Enter <strong>your</strong> Cell Phone Number, area code first.</li>';
		$ctt_form .= '<li>Enter your text message in the box.</li>';

		if ($is_multi) { $ctt_form .= '<li>Select which office you want to text.</li>'; }

		$ctt_form .= '<li>Click "Send Text".</li>';
		$ctt_form .= '<li>A copy of this text will be sent to the office <strong>and</strong> to your cell phone.  The office\'s reply will also be sent to your cell phone where you can continue the text conversation.</li></ol>';

		$ctt_form .= '<i>Note: Mobile message and data rates from your cell phone carrier may apply.</i>';

		$ctt_form .= '<img src="' . plugins_url('img/Close.svg', __FILE__) . '" id="clickToCallClose" alt="Close ClickToCall Button" />';
		$ctt_form .= '</div>';
		$ctt_form .= '</div>';
		$ctt_form .= '</div>';

		echo $ctt_form;
	}

	$pm_ctt_rendered = true;
}
