<?php
/**
 * DCMO Prospecta Plugin Styles & Scripts
 *
 * @package dcmo-prospecta
 */

/**
 * Prospecta Body Class
 * 
 * Adds a 'prospecta' class to the body element
 * 
 * @author DentalCMO - Alex Taylor
 * @return array after having 'prospecta' added as an item
 */
add_filter('body_class', 'is_prospecta_class');
function is_prospecta_class($classes) {
	// add 'class-name' to the $classes array
	$classes[] = 'prospecta';
	// return the $classes array
	return $classes;
}

/**
 * Prospecta Enqueues
 * 
 * Enqueues the styles and scripts necessary for a Prospecta site
 * 
 * @author DentalCMO - Alex Taylor
 */
add_action( 'wp_enqueue_scripts', 'pm_styles_scripts' );
function pm_styles_scripts() {
	$options = get_option('dcmo_pm_options','');

	wp_enqueue_style('dcmo-prospecta', plugins_url('/css/ctt-form.css', __FILE__));
	wp_enqueue_script('dcmo-prospecta', plugins_url('/js/ctt-form.js', __FILE__), array('jquery') , '', true  );

	if (!empty($options['num_replacer'])) {
		wp_add_inline_script('dcmo-prospecta', $options['num_replacer']);
	}
}