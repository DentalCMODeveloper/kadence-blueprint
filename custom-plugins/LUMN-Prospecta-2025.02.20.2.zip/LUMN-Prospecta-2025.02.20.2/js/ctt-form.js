(function ($) {

    /** Adds CTT overlay toggle */
    jQuery(".click-to-call").click(function () {
        jQuery("#clickToCallOverlay").removeClass("hide");
    });
    jQuery("#clickToCallOverlay").click(function () {
        jQuery("#clickToCallOverlay").addClass("hide");
    });
    jQuery("#clickToCallClose").click(function () {
        jQuery("#clickToCallOverlay").addClass("hide");
    });
    jQuery("#clickToCallOverlay > div").click(function (e) {
        e.stopPropagation();
    });
    jQuery('a[href^="sms"]').click(function (e) {
        if (jQuery(window).width() > 768) {
            e.preventDefault();
            jQuery("#clickToCallOverlay").removeClass("hide");
        }
    });

}(jQuery));

/* ProspectaMarketing Click to Text Functions */
/* This function moves the cursor to the next element */
function autotab(element, nextElement) {
    if (element.value.length == element.maxLength && nextElement != null) {
        element.form.elements[nextElement].focus();
    }
    document.getElementById("ctcPhone").value = document.getElementById("PhoneNumber1").value + document.getElementById("PhoneNumber2").value + document.getElementById("PhoneNumber3").value
}

/* this function will set the focus to the area code textbox */
function setfocus(fieldID) {
    document.getElementById(fieldID).focus();
}

/* this function makes sure that only numbers are input */
function isNumberKey(element, evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode

    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;

    document.getElementById("ctcPhone").value = document.getElementById("PhoneNumber1").value + document.getElementById("PhoneNumber2").value + document.getElementById("PhoneNumber3").value
    return true;
}
jQuery(document).ready(function () {
    jQuery("#originatingurl").val(window.location.href);
    jQuery("#originatingurl").attr("value", window.location.href);
    if (typeof (Storage) !== "undefined") {
        if (sessionStorage.getItem("referringurl") === null) {
            sessionStorage.setItem("referringurl", document.referrer);
        }
        jQuery("#referringurl").val(sessionStorage.getItem("referringurl"));
        jQuery("#referringurl").attr("value", sessionStorage.getItem("referringurl"));
        jQuery(".referer-page input").val(sessionStorage.getItem("referringurl"));
        jQuery(".referer-page input").attr("value", sessionStorage.getItem("referringurl"));
    }
    else {
        jQuery("#referringurl").val("");
        jQuery("#referringurl").attr("value", "");
        jQuery(".referer-page input").val("");
        jQuery(".referer-page input").attr("value", "");
    }
});
/* End ProspectaMarketing Click to Text Functions */