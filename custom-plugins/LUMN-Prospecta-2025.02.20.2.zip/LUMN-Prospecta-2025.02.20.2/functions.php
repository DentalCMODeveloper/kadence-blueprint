<?php

$options = get_option('dcmo_pm_options',array());

function getIP() {
	$sProxy = '';
	if ( getenv( 'HTTP_CLIENT_IP' ) ) {
		$sProxy = $_SERVER['REMOTE_ADDR'];
		$sIP	= getenv( 'HTTP_CLIENT_IP' ) ;
	} else {
		$sIP	= $_SERVER['REMOTE_ADDR'];
	}
	if ( ! empty( $sProxy ) ) {
		$sIP = $sIP . 'via-proxy:' . $sProxy;
	}
	return $sIP;
}

function setRefererTransient( $uniqueID ) {
	if ( false === ( $void = get_transient( $uniqueID ) ) ) {
		// set a transient for 2 hours
		if (isset($_SERVER['HTTP_REFERER'])) {
			set_transient( $uniqueID, $_SERVER['HTTP_REFERER'], 60*60*2 );
		}
	}
}

function getRefererPage( $form_tag ) {
	if ( $form_tag['name'] == 'referer-page' ) {
		$uniqueID = getIP();
		setRefererTransient( $uniqueID );
		$form_tag['values'][] =  get_transient( $uniqueID );
	}
	return $form_tag;
}

add_action('wp_ajax_dcmo_pm_create_post', 'dcmo_pm_create_post');
function dcmo_pm_create_post() {
	switch($_POST['create']) {
		case 'ctt_ty':
			$details = array(
				'post_type' => 'page',
				'post_status' => 'publish',
				'post_title' => 'Thank You For Your Text',
				'post_name' => 'thank-you-for-your-text',
				'post_content' => '<p>Thank you for your text. Someone from our office will reply as soon as they can during our business hours.</p><p>If you do not receive a text response right away and it is during business hours, we may be with a patient.  Please know we value each current, new and potential patient\'s time, and will text you as soon as possible.</p><p>Note: A copy of the text you just sent will be sent to your phone to be part of the thread.</p>'
			);
			break;
		case 'form_ty':
			$details = array(
				'post_type' => 'page',
				'post_status' => 'publish',
				'post_title' => 'Thanks For Your Email',
				'post_name' => 'thanks-for-your-email',
				'post_content' => '<p>Thank you. Your message has been sent. Someone from our office will be contacting you shortly.</p>[dcmo_previous]'
			);
			break;
		default:
			return 'Not sure what to create.';
	}

	$post_id = wp_insert_post($details);
	
	if (!is_wp_error($post_id)) {
	  echo 'true';
	} else {
	  echo $post_id->get_error_message();
	}

	wp_die();
}

if ( !is_admin() ) {
	add_filter( 'wpcf7_form_tag', 'getRefererPage' );
}

if ($options['crc_enabled'] === '1') {
	add_filter( 'the_content', function($content) {
		$related = do_shortcode("[custom-related-posts title='Related Content']");
		if ( strpos($related, "None found") === false ) {
			$content .= $related;
		}
		return $content;
	});
}