<?php
/**
 * DCMO Prospecta Plugin Menu Page
 *
 * @package dcmo-prospecta
 */

/**
 * DCMO Prospecta Plugin Menu Page
 *
 * @author DentalCMO - Alex Taylor
 */
add_action( 'admin_menu', function () {
	add_menu_page(__('Prospecta Options','dcmo_pm'), 'Prospecta Options', 'customize', sanitize_key('dcmo-prospecta'), function() {
		if( current_user_can( 'customize' ) ) {
			$options = get_option('dcmo_pm_options',array(
				'acc_id' => '123',
				'is_multi' => false,
				'multi_details' => array(
					array('Default','123')
				),
				'num_replacer' => '',
				'practice_name' => '',
			));
			$dupe = '<section class="multi" data-count="%count%">' .
					'<label for="dcmo_pm_multi_acc_label_%count%">CTT Account Label:</label>' .
					'<input type="text" name="dcmo_pm_multi_acc_label_%count%" value="%acc_label%">' .
					'<label for="dcmo_pm_multi_acc_id_%count%">CTT Account ID:</label>' .
					'<input type="text" name="dcmo_pm_multi_acc_id_%count%" value="%acc_id%">' .
					'<button class="delete">Delete</button>' .
				'</section>';
			$dcmo_pm_nonce = wp_create_nonce( 'dcmo_pm_form_nonce' ); ?>
			<style>
				dd { margin: 0; }
				form section {
					margin-bottom: 20px;
					padding: 10px;
					background-color: #fff;
				}
				form input[type=text], form textarea {
					width:100%;
				}
				form input[name="dcmo_pm_acc_id"] {
					width:120px;
				}
				form input[name="dcmo_pm_practice_name"] {
					width: 400px;
    				margin-bottom: 25px;
				}
				form p {
					margin: 10px 0 0;
				}

				input[name="dcmo_pm_is_multi"]:checked ~ .single { display: none; }
				input[name="dcmo_pm_is_multi"]:not(:checked) ~ .multi { display: none; }

				section.single {
					padding: 0;
					margin: 0;
				}

				section.multi {
					display: grid;
					grid-template-columns: 120px 100px;
				}

				.delete {
					width: 55px;
					background-color: #f7a5a5;
					border: 0;
					border-radius: 5px;
				}

				.success {
					color: #4BB543;
				}

				.failure {
					background-color: #FFCCCC;
				}
			</style>
			<script>
				function init_delete(element) {
					element.click(function(){
						jQuery(this).parent().remove();
					});
				}
				jQuery(document).ready(function(){
					jQuery('.delete').each(function(){
						init_delete(jQuery(this));
					});
					jQuery('#addAccount').click(function(e){
						e.preventDefault();
						var count = Number(jQuery('#accs section.multi:last-of-type').attr('data-count'));
						count = ((Number.isNaN(count)) ? -1 : count);
						var dupe = '<?= $dupe; ?>';
						count++;

						dupe = dupe.replace(/%count%/g, count);
						dupe = dupe.replace('%acc_label%', '');
						dupe = dupe.replace('%acc_id%', '');

						jQuery(this).before(dupe);

						init_delete(jQuery('#accs section.multi:last-of-type .delete'));
					});
					jQuery('.create_post').click(function(){
						element = jQuery(this);
						create = jQuery(this).attr('data-create');
						jQuery.post(
							document.location.origin+"/wp-admin/admin-ajax.php",
							{
								'action': 'dcmo_pm_create_post',
								'create': create
							},
							function(response) {
								console.log(response);
								if (response == 'true') {
									element.replaceWith('<span class="success">Page created successfully.</span>');
								} else {
									element.replaceWith('<span class="failure">A problem occurred. ' + response + ' Please correct the issue or try again later.</span>');
								}
							}
						);
					});
				});
			</script>
			<h1>
				<?php esc_html_e('Prospecta Options','dcmo_pm') ?>
			</h1>
			<form action="<?= esc_url( admin_url( 'admin-post.php' ) ); ?>" method="post" id="dcmo_pm_form">
				<section id="accs">
					<h2>Click To Text Form</h2>
					<dd>Automatically replaces sms links with the Prospecta texting form on desktop.</dd>
					<br>
					<label for="dcmo_pm_practice_name"> <?php _e("Practice Name:",'dcmo_pm'); ?> </label>
					<input type="text" name="dcmo_pm_practice_name" value="<?= esc_attr($options['practice_name']); ?>">
					<br>
					<label for="dcmo_pm_is_multi"> <?php _e("Multiple CTT account IDs?",'dcmo_pm'); ?> </label>
					<input type="checkbox" name="dcmo_pm_is_multi" value="true" <?= esc_attr(($options['is_multi'] === '1') ? 'checked' : '') ?>>
					<section class="single">
						<label for="dcmo_pm_acc_id"> <?php _e("CTT Account ID:",'dcmo_pm'); ?> </label>
						<input type="text" name="dcmo_pm_acc_id" value="<?= esc_attr($options['acc_id']); ?>">
						<dd></dd>
					</section>
					<?php
						foreach($options['multi_details'] as $key => $values) {
							$curr_dupe = str_replace(array(
									'%count%',
									'%acc_label%',
									'%acc_id%'
								), array(
									$key,
									esc_attr($values[0]),
									esc_attr($values[1])
								), $dupe);

							echo $curr_dupe;
						}
					?>
					<button id="addAccount" class="multi">Add Account ID</button>
				</section>

				<section>
					<label for="dcmo_pm_num_replacer"> <?php _e("Number Replacer Script:",'dcmo_pm'); ?> </label>
					<textarea name="dcmo_pm_num_replacer" rows="10"><?= esc_attr($options['num_replacer']); ?></textarea>
					<dd>Script tags should not be used.</dd>
				</section>
				<section>
					<label for="dcmo_pm_crc_enabled"> <?php _e("Enable Custom Related Content",'dcmo_pm'); ?></label>
					<input type="checkbox" name="dcmo_pm_crc_enabled" value="true" <?= esc_attr(($options['crc_enabled'] === '1') ? 'checked' : '') ?>>
					<dd>This option uses the Custom Related Posts plugin and will only include the section on the page if related content has been selected for that page.</dd>
				</section>
				<input type="hidden" name="action" value="dcmo_pm_form_response">
				<input type="hidden" name="dcmo_pm_nonce" value="<?= $dcmo_pm_nonce ?>" />
				<p class="submit"><input type="submit" name="submit" id="submit" class="button button-primary" value="Save"></p>
			</form>
			<section>
				<h2>Setup</h2>
				<?php if (!get_page_by_path('thank-you-for-your-text')) { ?>
					<div class="create_post_cont">Click to Text Thank You page is not set up yet. <button class="create_post" data-create="ctt_ty">Create It Now</button></div>
				<?php } ?>
				<?php if (!get_page_by_path('thanks-for-your-email')) { ?>
					<div class="create_post_cont">Form submission Thank You page is not set up yet. <button class="create_post" data-create="form_ty">Create It Now</button></div>
				<?php } ?>
			</section>
			<div id="nds_form_feedback"></div>
		<?php } else { ?>
			<p><?php __('You are not authorized to perform this operation.', 'dcmo_pm') ?></p>
		<?php }

	}, '', null );
});

/**
 * Prospecta Options Form Handling
 *
 * Handles the submission of settings defined on the dashboard page.
 *
 * @author DentalCMO - Alex Taylor
 */
add_action( 'admin_post_dcmo_pm_form_response', function () {
	if( isset( $_POST['dcmo_pm_nonce'] ) && wp_verify_nonce( $_POST['dcmo_pm_nonce'], 'dcmo_pm_form_nonce') ) {
		$options = get_option('dcmo_pm_options',array(
			'acc_id' => '123',
			'is_multi' => false,
			'multi_details' => array(
				array('Default','123')
			),
			'num_replacer' => '',
			'practice_name' => '',
		));
		// sanitize the input
		$options['acc_id'] = sanitize_text_field( $_POST['dcmo_pm_acc_id'] ?? '123' );
		$options['is_multi'] = sanitize_text_field( ($_POST['dcmo_pm_is_multi'] === 'true') ?? false );
		$options['num_replacer'] = stripslashes_deep(wp_kses_post($_POST['dcmo_pm_num_replacer'] ?? ''));
		$options['crc_enabled'] = sanitize_text_field( ($_POST['dcmo_pm_crc_enabled'] === 'true') ?? false );
		$options['practice_name'] = sanitize_text_field($_POST['dcmo_pm_practice_name'] ?? '');

		$options['multi_details'] = array();
		foreach ($_POST as $key => $value) {
			if (strpos($key, 'dcmo_pm_multi_acc_label') === 0) {
				$matches = array();

				preg_match('/_([0-9]*)$/i', $key, $matches);

				if (!empty($matches)) {
					$options['multi_details'][$matches[1]] = array(
						sanitize_text_field( $_POST['dcmo_pm_multi_acc_label_' . $matches[1]] ?? '' ),
						sanitize_text_field( $_POST['dcmo_pm_multi_acc_id_' . $matches[1]] ?? '' )
					);
				}
			}
		}

		update_option('dcmo_pm_options', $options);

		// add the admin notice
		wp_redirect('/wp-admin/admin.php?page=dcmo-prospecta');
		exit;
	}
	else {
		wp_die( __( 'Invalid nonce specified', 'dcmo_pm' ), __( 'Error', 'dcmo_pm' ), array(
			'response' 	=> 403,
			'back_link' => 'admin.php?page=dcmo-prospecta',
		) );
	}
});
