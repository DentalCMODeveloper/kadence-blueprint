<?php
/*
Plugin Name: LUMN Utilites 2
Plugin URI: https://getlumn.com
Description: A set of custom shortcodes and tools for LUMN sites.
Version: 2024.12.02
Author: LUMN
Author URI: https://getlumn.com
License: GPL2
*/
namespace Lumn\Utilities2;

// Define the plugin path
define( 'LUMN_UTILITIES_2_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );

// Register Functions
require_once(LUMN_UTILITIES_2_PLUGIN_PATH . 'register/functions.php');

// Register Sections
require_once(LUMN_UTILITIES_2_PLUGIN_PATH . 'register/sections.php');

// Register Fields
require_once(LUMN_UTILITIES_2_PLUGIN_PATH . 'register/fields.php');

// Register Shortcodes
require_once(LUMN_UTILITIES_2_PLUGIN_PATH. 'register/shortcodes.php');

// Register Redirects
require_once(LUMN_UTILITIES_2_PLUGIN_PATH. 'register/redirects.php');

// Enqueue admin scripts and styles
function lumn_ut_2_admin_scripts() {
    wp_enqueue_style( 'lumn-ut-2-admin-styles', plugins_url( '/admin/admin-styles.css' , __FILE__ ));
    wp_enqueue_script( 'lumn-ut-2-admin-scripts', plugins_url( '/admin/admin-scripts.js' , __FILE__ ), array( 'jquery' ) );
}
add_action( 'admin_enqueue_scripts', 'Lumn\Utilities2\lumn_ut_2_admin_scripts' );

// Public facing styles
function lumn_ut_2_public_scripts() {
    wp_enqueue_style( 'lumn-ut-2-styles', plugins_url( 'styles.css' , __FILE__ ));
}
add_action( 'wp_enqueue_scripts', 'Lumn\Utilities2\lumn_ut_2_public_scripts' );

// Enable update checker
require LUMN_UTILITIES_2_PLUGIN_PATH . 'plugin-update-checker/plugin-update-checker.php';
use YahnisElsts\PluginUpdateChecker\v5\PucFactory;
$myUpdateChecker = PucFactory::buildUpdateChecker(
	'https://getlumn.com/lumn-utilites-2/version.json',
	__FILE__,
	'lumn-utilites-2'
);