=== Kadence White Label ===
Contributors: britner
Tags: 
Requires at least: 6.0
Tested up to: 6.7.1
Stable tag: 1.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Control the branding of the Kadence Theme.

== Description ==

Control the branding of the Kadence Theme.

== Installation ==

Install the plugin into the `/wp-content/plugins/` folder, and activate it.


== Changelog ==

== 1.0.1 | 30th January 2025 ==
* Fix: Kadence Blocks Pro not white labeled on dashboard updates page

== 1.0.0 | 16th April 2024 ==
* Update: initial release.