<?php

namespace KadenceWP\KadenceWhiteLabel\Uplink;

class Helper {
	/**
	 * @var string Helper data
	 */
	const DATA = '';

}