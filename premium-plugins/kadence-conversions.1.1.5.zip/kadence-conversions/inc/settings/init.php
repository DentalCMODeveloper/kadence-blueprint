<?php
/**
 * Bring in the Kadence Settings Engine.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once dirname( __FILE__ ) . '/class-kadence-settings-engine.php';
require_once dirname( __FILE__ ) . '/class-kadence-settings.php';
