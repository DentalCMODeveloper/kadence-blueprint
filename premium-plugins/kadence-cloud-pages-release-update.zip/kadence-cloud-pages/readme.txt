=== Kadence Pattern Hub - Page Addon ===
Contributors: britner
Requires at least: 6.2
Tested up to: 6.8
Stable tag: 1.1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Extends the pattern hub to have a pages element.

== Description ==

== Installation ==

Install the plugin into the `/wp-content/plugins/` folder, and activate it. This plugin is an extension of Kadence Pattern Hub.

== Frequently Asked Questions ==

= Where do I report security bugs found in this plugin? =

Please report security bugs found in the source code of the
Kadence Pattern Hub - Page Addon plugin through the Patchstack
Vulnerability Disclosure Program https://patchstack.com/database/vdp/kadence-cloud-pages. The
Patchstack team will assist you with verification, CVE assignment, and
notify the developers of this plugin.

== Security Policy ==

= Reporting Security Bugs =

Please report security bugs found in the
Kadence Pattern Hub - Page Addon plugin's source code through the
Patchstack Vulnerability Disclosure
Program https://patchstack.com/database/vdp/kadence-cloud-pages. The Patchstack team will
assist you with verification, CVE assignment, and notify the
developers of this plugin.

== Changelog ==

== 1.0.0 ==
* Initial Release.
