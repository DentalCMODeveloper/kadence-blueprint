<?php

namespace KadenceWP\CloudPages\Uplink;

class Helper {
	/**
	 * @var string Helper data
	 */
	const DATA = '';

}