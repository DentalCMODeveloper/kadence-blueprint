=== Kadence Pattern Hub - SureCart Licensing ===
Contributors: britner
Requires at least: 6.0
Tested up to: 6.7
Stable tag: 1.0.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Extends the licensing to work with SureCart.

== Description ==

== Installation ==

Install the plugin into the `/wp-content/plugins/` folder, and activate it. This plugin is an extension of Kadence Cloud.

== Frequently Asked Questions ==

= Where do I report security bugs found in this plugin? =

Please report security bugs found in the source code of the
Kadence Cloud - Surecart Addon plugin through the Patchstack
Vulnerability Disclosure Program https://patchstack.com/database/vdp/kadence-cloud-surecart-license. The
Patchstack team will assist you with verification, CVE assignment, and
notify the developers of this plugin.

== Security Policy ==

= Reporting Security Bugs =

Please report security bugs found in the
Kadence Cloud - Surecart Addon plugin's source code through the
Patchstack Vulnerability Disclosure
Program https://patchstack.com/database/vdp/kadence-cloud-surecart-license. The Patchstack team will
assist you with verification, CVE assignment, and notify the
developers of this plugin.

== Changelog ==

== 1.0.4 ==
* Fix: Issue with non SureCart keys and making new connections.

== 1.0.3 ==
* Update: Fix issue with Use collection name as pattern hub name.

== 1.0.2 ==
* Update: SureCart api client to handle requests differently.

== 1.0.1 ==
* Fix: Add newly required public key.
* Update: plugin name.

== 1.0.0 ==
* Initial Release.
