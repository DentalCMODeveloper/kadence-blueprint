<?php

namespace KadenceWP\ReCaptcha\Uplink;

class Helper {
	/**
	 * @var string Helper data
	 */
	const DATA = '';

}