<?php

namespace KadenceWP\KadenceGalleries\Uplink;

class Helper {
	/**
	 * @var string Helper data
	 */
	const DATA = '';

}