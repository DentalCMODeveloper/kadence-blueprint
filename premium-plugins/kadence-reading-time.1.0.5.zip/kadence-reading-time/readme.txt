=== Kadence Reading Time ===
Contributors: KadenceWP
Tags: 
Requires at least: 4.4
Tested up to: 6.7.2
Stable tag: 1.0.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A Simple plugin to add reading time to your posts. 

== Description ==

A Simple plugin to add reading time to your posts. 


== Installation ==

Install the plugin into the `/wp-content/plugins/` folder, and activate it.

== Frequently Asked Questions ==

= Where do I report security bugs found in this plugin? =

Please report security bugs found in the source code of the
Kadence Reading Time plugin through the Patchstack
Vulnerability Disclosure Program https://patchstack.com/database/vdp/kadence-reading-time. The
Patchstack team will assist you with verification, CVE assignment, and
notify the developers of this plugin.

== Security Policy ==

= Reporting Security Bugs =

Please report security bugs found in the
Kadence Reading Time plugin's source code through the
Patchstack Vulnerability Disclosure
Program https://patchstack.com/database/vdp/kadence-reading-time. The Patchstack team will
assist you with verification, CVE assignment, and notify the
developers of this plugin."

== Changelog ==

= 1.0.5 =
* Update: Tested up to WP 6.7
* Fix: PHP 8.2 deprecation notice.

= 1.0.4 =
* Fix: PHP 8.2 deprecation notice.

= 1.0.3 =
* Add: option to included outside of the theme meta.

= 1.0.2 =
* Update: Just show that it's still alive.

= 1.0.1 =
* Add Language File


= 1.0.0 =
* inital release
