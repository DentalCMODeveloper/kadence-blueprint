<?php

namespace KadenceWP\KadenceShopKit\Uplink;

class Helper {
	/**
	 * @var string Helper data
	 */
	const DATA = 'ktm_wc_order_4LKyVSG3YmThS_am_xERGCNCYW6DC';

}