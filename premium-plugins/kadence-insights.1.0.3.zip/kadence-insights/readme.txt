=== Kadence Insights - AB Testing ===
Contributors: kadencewp
Donate link: https://kadencewp.com
Tags: animation
Requires at least: 6.4
Tested up to: 6.7.2
Stable tag: 1.0.3
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Kadence Insights - No-code solution for A/B testing content on your site.

== Description ==

Kadence Insights - No-code solution for A/B testing content on your site.


== Installation ==

This section describes how to install Kadence Insights and get it working.

e.g.

1. Upload the plugin files to the `/wp-content/plugins/kadence-insights` directory, or install the plugin through the WordPress plugins screen directly.
1. Activate the plugin through the 'Plugins' screen in WordPress
1. That's it!

== Changelog ==

== 1.0.3 | 7th April 2025 ==
* Update: Improve how usage locations is stored.
* Update: Allow embed keys.

== 1.0.2 | 5th December 2024 ==
* Update: Add preview link in block.
* Update: Add usage locations in ab list.
* Fix: Analytics chart when 0 data for current day.

== 1.0.1 | 18th November 2024 ==
* Update: Tweak Goal Tracking.
* Update: Test Updater.

== 1.0.0 | 18th November 2024 ==
* Update: Initial release.
