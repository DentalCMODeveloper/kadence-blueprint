<?php

namespace KadenceWP\KadenceCloud\Uplink;

class Helper {
	/**
	 * @var string Helper data
	 */
	const DATA = '';

}