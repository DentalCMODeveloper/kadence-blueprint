<?php
namespace KadenceWP\KadenceCloud;

use KadenceWP\KadenceCloud\StellarWP\Schema\Config;
use KadenceWP\KadenceCloud\StellarWP\DB\DB;
use KadenceWP\KadenceCloud\Container;
use KadenceWP\KadenceCloud\StellarWP\Schema\Register;
use KadenceWP\KadenceCloud\Tables\Analytics_Table;
/**
 * Load Plugin
 */
function kadence_cloud_analytics_init() {
	Config::set_container( new Container() );
	Config::set_db( DB::class );
	require_once KADENCE_CLOUD_PATH . 'inc/kadence-cloud-analytics-table.php';
	require_once KADENCE_CLOUD_PATH . 'inc/kadence-cloud-analytics-dashboard-util.php';
	/**
	 * Register database table.
	 */
	Register::table( Analytics_Table::class );
}
add_action( 'plugins_loaded', 'KadenceWP\KadenceCloud\kadence_cloud_analytics_init' );
