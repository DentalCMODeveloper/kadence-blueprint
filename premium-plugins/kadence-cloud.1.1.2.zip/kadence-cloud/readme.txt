=== Kadence Pattern Hub ===
Contributors: britner
Tags: 
Requires at least: 6.0
Tested up to: 6.7
Stable tag: 1.1.2
Requires PHP: 7.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Create your own remote hub of shareable prebuilt block patterns.

== Description ==

Create your own remote hub of shareable prebuilt block patterns.

== Installation ==

Install the plugin into the `/wp-content/plugins/` folder, and activate it.

== Frequently Asked Questions ==

= Where do I report security bugs found in this plugin? =

Please report security bugs found in the source code of the
Kadence Cloud plugin through the Patchstack
Vulnerability Disclosure Program https://patchstack.com/database/vdp/kadence-cloud. The
Patchstack team will assist you with verification, CVE assignment, and
notify the developers of this plugin.

== Security Policy =

= Reporting Security Bugs =

Please report security bugs found in the
Kadence Cloud plugin's source code through the
Patchstack Vulnerability Disclosure
Program https://patchstack.com/database/vdp/kadence-cloud. The Patchstack team will
assist you with verification, CVE assignment, and notify the
developers of this plugin.

== Changelog ==

== 1.1.2 | 23rd July 2025 ==
* Update: Pages addon support.
* Fix: Error when adding site to multisite install.

== 1.1.1 | 30th April 2025 ==
* Update: Better error responses for troubleshooting.
* Update: Prep for pages addon.
* Update: Prep for CPT support.
* Fix: Possible issue with users seeing Invalid Request, Incorrect Pattern
* Fix: Added more safety checks to telemetry opt-ins/opt-outs.

== 1.1.0 | 26th February 2024 ==
* Add: New Options for anonymous usage analytics.
* Update: Change name to Pattern Hub.
* Update: Licensing and Updater.
* Update: Settings panel.
* Update: Support added for custom category order.

== 1.0.8 | 15th February 2023 ==
* Update: Post Labels.
* Update: Edit post missing on front end.

== 1.0.7 | 16th January 2023 ==
* Update: Settings Base for SureCart Addon.

== 1.0.6 | 18th July 2022 ==
* Update: Settings Base.

== 1.0.5 | 7th September 2021 ==
* Update: Allow for multiple connections based on key.

== 1.0.4 | 24th May 2021 ==
* Update: License Key option for ithemes.

== 1.0.3 | 19th May 2021 ==
* Add: License Key option to limit by collection.

== 1.0.2 | 4th May 2021 ==
* Add: Collections Taxonomy.
* Add: Option to add notes to access keys.
* Fix: Issue with Custom Cloud Name.

== 1.0.1 | 30th April 2021 ==
* Update: Tweak api calls.

== 1.0.0 | 26th April 2021 ==
* Update: initial release.
