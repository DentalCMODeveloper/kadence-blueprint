<?php

if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}

class FrmProComment {

	/**
	 * @deprecated 6.16.1
	 */
	public static function create_comment( $entry_id, $form_id ) {
		_deprecated_function( __METHOD__, '6.16.1' );
	}
}
