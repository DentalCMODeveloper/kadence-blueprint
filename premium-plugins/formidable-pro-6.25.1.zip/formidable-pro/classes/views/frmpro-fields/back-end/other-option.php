<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( 'You are not allowed to call this page directly.' );
}
?>
<div class="frm-add-other frm_form_field frm-flex frm-justify-end frm-flex-wrap <?php echo empty( FrmField::get_option( $field, 'image_options' ) ) ? '' : 'frm_hidden'; ?>" id="frm_add_field_<?php echo esc_attr( $field['id'] ); ?>">
	<a href="javascript:void(0);" id="other_button_<?php echo esc_attr( $field['id'] ); ?>" data-opttype="other" data-ftype="<?php echo esc_attr( $field['type'] ); ?>" class="frm-small-add frm_cb_button frm_add_opt<?php echo ( $hide_other ? ' frm_hidden' : '' ); ?>" data-clicks="0">
		<?php
		FrmAppHelper::icon_by_class( 'frm_icon_font frm_plus1_icon frm_add_tag frm_svg13' );
		esc_html_e( 'Add "Other"', 'formidable-pro' );
		?>
	</a>
</div>

<input type="hidden" value="<?php echo esc_attr( $field['other'] ); ?>" id="other_input_<?php echo esc_attr( $field['id'] ); ?>" name="field_options[other_<?php echo esc_attr( $field['id'] ); ?>]" />
