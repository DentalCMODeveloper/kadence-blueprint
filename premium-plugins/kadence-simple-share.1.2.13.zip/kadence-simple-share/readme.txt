=== Kadence Simple Share ===
Contributors: Kadence WP
Tags: 
Requires at least: 5.4
Tested up to: 6.7.2
Stable tag: 1.2.13
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Simple plugin for sharing posts on social networks

== Description ==

Simple plugin for sharing posts on social networks

== Installation ==

Install the plugin into the `/wp-content/plugins/` folder, and activate it.

== RoadMap ==
** Update: New Admin Panel.
** Add: Line
** Add: Wechat.
** Add: Weibo

== Frequently Asked Questions ==

= Where do I report security bugs found in this plugin? =

Please report security bugs found in the source code of the
Kadence Simple Share plugin through the Patchstack
Vulnerability Disclosure Program https://patchstack.com/database/vdp/kadence-simple-share. The
Patchstack team will assist you with verification, CVE assignment, and
notify the developers of this plugin.

== Security Policy ==

= Reporting Security Bugs =

Please report security bugs found in the
Kadence Simple Share plugin's source code through the
Patchstack Vulnerability Disclosure
Program https://patchstack.com/database/vdp/kadence-simple-share. The Patchstack team will
assist you with verification, CVE assignment, and notify the
developers of this plugin.

== Changelog ==

= 1.2.13 | February 11th 2025 =
* Fix: issue with "none" placement.

= 1.2.12 | 2nd May 2024 =
* Fix: PHP notices.
* Fix: Possible issue with select2

= 1.2.11 | 24th January 2024 =
* Update: Twitter Logo

= 1.2.10 | 17th August 2023 =
* Fix: Shortcode CSS.

= 1.2.9 | 14th August 2023 =
* Fix: Possible issue where small window popup url wasn't being set correctly.

= 1.2.8 | 11th August 2023 =
* Update: Standardize svg format for better cross browser support.

= 1.2.7 | 10th August 2023 =
* Update: Added options for placing sharing elements in fixed positions.
* Update: Use inline svgs instead of icon font.
* Update: PHP deprecations.
* Fix: Redux plugin conflict.
* FIx: Twitter share.

= 1.2.6 | 29th March 2023 =
* Update: Change stable tags

= 1.2.5 | 12th September 2020 =
* Update: Links to use HTTPs by default.
* Fix Pinterest Blank.
* Fix: Possible php error with REMOTE_ADDR

= 1.2.4 | 29th June 2020 =
* Add: WhatsApp.

= 1.2.3 | 27th March 2020 =
* Add: Xing.
* Remove: Google+
* Update: JS, no need for jQuery.
* Update: Meta, move to sidebar.
* Update: Tooltip, css only solution.
* Add: No JS method, links open new tab instead of window.

= 1.2.2 | 16th April 2018 =
* Add: Excerpt sharing icons.

= 1.2.1 | 16th March 2018 =
* Fix: Issue with membership endless loop.
* Update: Simplify Meta

= 1.2.0 | 4th January 2018 =
* Add: Pinterest
* Add: Reddit
* Update: Font add woff2

= 1.1.0 | 4th January 2017 =
* Add: Page by page meta box to turn off social icons.
* Add: Support for non Kadence Themes

= 1.0.0 =
* Initial Version.
