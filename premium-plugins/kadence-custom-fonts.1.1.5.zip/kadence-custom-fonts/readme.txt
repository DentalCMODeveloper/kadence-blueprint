=== Kadence Custom Fonts ===
Contributors: KadenceWP
Tags: 
Requires at least: 4.4
Tested up to: 6.1
Stable tag: 1.1.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A simple plugin to add custom fonts for Kadence WP.

== Description ==

A simple plugin to add custom fonts for Kadence WP. 
Helpful links:
https://www.web-font-generator.com/
http://google-webfonts-helper.herokuapp.com/fonts


== Installation ==

Install the plugin into the `/wp-content/plugins/` folder, and activate it.


== Changelog ==

= 1.1.5 =
* Fix: Possible issue with cmb autoloader

= 1.1.4 =
* Fix: Possible issue with some adobe fonts.
* Fix: Widget Editor issue.

= 1.1.3 =
* Fix: Editor iframe issue.

= 1.1.2 =
* Add: Fallback option.
* Update: Conditional CMB to prevent conflicts.
* Fix: Typo.

= 1.1.1 =
* Update: font load order.
* Update: Issue with multisite.

= 1.1.0 =
* Add: Adobe Font Option.
* Add: 5.6 Support.
* Update: Plugin updater.

= 1.0.4 =
* Add: Font Swap.
* Add: Fonts show in Elementor and Beaver

= 1.0.3 =
* Add: Kadence Theme Support.

= 1.0.2 =
* Add: Kadence Blocks Support.

= 1.0.1 =
* Fix: typo.
* Add: Kadence Pricing table support.
* Add: Translation files

= 1.0.0 =
*initial release