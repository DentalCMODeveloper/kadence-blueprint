export const POSTS_METADATA_ROUTE = '/kb-optimizer/v1/optimize/posts-metadata';
export const BULK_DELETE_ROUTE = '/kb-optimizer/v1/optimize/bulk/delete';
