import { createLazyLoader } from './lazy-loader';

const lazyLoader = createLazyLoader();
lazyLoader.observeElements();
