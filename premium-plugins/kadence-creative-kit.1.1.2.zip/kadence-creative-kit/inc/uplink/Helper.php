<?php

namespace KadenceWP\CreativeKit\Uplink;

final class Helper {
	/**
	 * @var string Helper data
	 */
	const DATA = 'ktm_wc_order_4LKyVSG3YmThS_am_xERGCNCYW6DC';
}