=== Kadence Creative Kit ===
Contributors: oakesjosh, kadencewp
Donate link: https://kadencewp.com
Tags: AI, page builder
Requires at least: 6.4
Tested up to: 6.9
Stable tag: 1.1.2
Requires PHP: 7.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Kadence Creative Kit - Premium Designs, AI Page Generator.

== Description ==

Kadence Creative Kit - Premium Designs, AI Page Generator.


== Installation ==

This section describes how to install Kadence Creative Kit and get it working.

e.g.

1. Upload the plugin files to the `/wp-content/plugins/kadence-creative-kit` directory, or install the plugin through the WordPress plugins screen directly.
1. Activate the plugin through the 'Plugins' screen in WordPress
1. That's it!

== Changelog ==

== 1.1.2 | 29th January 2026 ==
* Update: Allow additional inner blocks inside the marque block.

== 1.1.1 | 24th October 2025 ==
* Fix: Ensure the marquee auto-scroll initializes in Safari.

== 1.1.0 | 23rd October 2025 ==
* Add: Marquee block.

== 1.0.2 | 5th May 2025 ==
* Fix: AOS with only nested inner blocks.

== 1.0.1 | 18th March 2025 ==
* Update: Allow for embed license keys.

== 1.0.0 | 16th January 2025 ==
* Update: Initial Release.
