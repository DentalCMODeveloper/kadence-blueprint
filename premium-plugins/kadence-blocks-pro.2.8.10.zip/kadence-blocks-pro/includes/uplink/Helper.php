<?php
/**
 * Class to Build the Helper
 */

namespace KadenceWP\KadenceBlocksPro\Uplink;

/**
 * Class to Build the Helper.
 *
 * @package Kadence Blocks
 */
class Helper {
	/**
	 * The Helper data
	 * 
	 * @var string Helper data
	 */
	const DATA = 'ktm_wc_order_4LKyVSG3YmThS_am_xERGCNCYW6DC';
}
