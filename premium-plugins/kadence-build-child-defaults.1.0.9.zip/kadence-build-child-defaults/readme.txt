=== Kadence Child Theme Builder ===
Contributors: britner
Tags: templates, gutenberg
Requires at least: 5.3
Tested up to: 6.7.1
Stable tag: 1.0.9
Requires PHP: 7.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Easily create a child theme with custom theme defaults and a custom starter template.

== Description ==
Easily create a child theme with custom theme defaults and a custom starter template.

== Changelog ==
= 1.0.9 =
* Update: Fixing an issue with a temp folder causing issues with exports.

= 1.0.8 =
* Update: references to "cloud" to "pattern hub".

= 1.0.7 =
* Fix: Issue with color palette missing from starter template.

= 1.0.6 =
* Update: Include woocommerce settings in import.
* Fix: Issue with dashes in theme slug.

= 1.0.5 =
* Add: Theme Slug (Folder Name) Option.
* Fix: Issue with version number.

= 1.0.4 =
* Add: New Settings for cloud library
* Update: Build Process

= 1.0.3 =
* Update: Better Child Stylesheet Creation.
* Update: Sanitize for single quotes in html areas.

= 1.0.2 =
* Fix: better support for any repo plugin.

= 1.0.1 =
* Update Plugin name.

= 1.0.0 =
* release